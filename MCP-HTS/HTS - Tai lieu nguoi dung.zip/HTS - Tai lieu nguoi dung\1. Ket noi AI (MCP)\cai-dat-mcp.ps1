﻿# Cài cầu nối MCP của HTS (cổng 5088) và VCS (cổng 5077) cho ứng dụng AI trên máy.
#   CaiDat-MCP.bat              → chép cầu nối + cấu hình Claude Desktop / Cursor (nếu có) + in cấu hình cho ứng dụng khác
#   CaiDat-MCP.bat -ChiChep     → chỉ chép cầu nối, không sửa cấu hình ứng dụng nào
#   KiemTra-KetNoi.bat          → (-KiemTra) gọi /mcp/health của HTS và VCS
param([switch]$ChiChep, [switch]$KiemTra)

$ErrorActionPreference = 'Stop'
$goc = Split-Path -Parent $MyInvocation.MyCommand.Path
$dich = Join-Path $env:PUBLIC 'HTS-MCP'
$hts = Join-Path $dich 'hts-mcp-bridge.js'
$vcs = Join-Path $dich 'vcs-mcp-bridge.js'

function Dong([string]$s, [string]$mau = 'Gray') { Write-Host $s -ForegroundColor $mau }

# ── Kiểm tra kết nối ─────────────────────────────────────────────
if ($KiemTra) {
    foreach ($m in @(@('HTS', 5088, 'gõ lệnh HTS và đăng nhập'), @('VCS', 5077, 'gõ lệnh VCS và đăng nhập'))) {
        try {
            $r = Invoke-RestMethod -Uri ("http://localhost:{0}/mcp/health" -f $m[1]) -TimeoutSec 4
            $bq = if ($r.PSObject.Properties['licensed']) { if ($r.licensed) { 'có bản quyền' } else { 'CHƯA đăng nhập bản quyền' } } else { 'đang chạy' }
            $so = if ($r.PSObject.Properties['toolCount']) { ', ' + $r.toolCount + ' công cụ' } else { '' }
            Dong ("[OK]   {0}: cổng {1} trả lời ({2}{3})." -f $m[0], $m[1], $bq, $so) 'Green'
        } catch {
            Dong ("[CHƯA] {0}: cổng {1} chưa trả lời. Mở AutoCAD, {2}." -f $m[0], $m[1], $m[2]) 'Yellow'
        }
    }
    exit 0
}

Dong ''
Dong '=== Cài cầu nối MCP HTS / VCS ===' 'Cyan'

# ── 1. Node.js ───────────────────────────────────────────────────
$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
    Dong 'Chưa có Node.js. Cài bản LTS ở https://nodejs.org/ rồi chạy lại tệp này.' 'Red'
    try { Start-Process 'https://nodejs.org/' } catch {}
    exit 1
}
$ver = (& $node.Source --version) 2>$null
$chinh = 0; if ($ver -match '^v(\d+)') { $chinh = [int]$Matches[1] }
if ($chinh -lt 18) { Dong ("Node.js {0} quá cũ, cần bản 18 trở lên: https://nodejs.org/" -f $ver) 'Red'; exit 1 }
Dong ("Node.js {0}: {1}" -f $ver, $node.Source) 'Green'

# ── 2. Chép cầu nối ──────────────────────────────────────────────
New-Item -ItemType Directory -Force -Path $dich | Out-Null
Copy-Item -LiteralPath (Join-Path $goc 'cau-noi\hts-mcp-bridge.js') -Destination $hts -Force
Copy-Item -LiteralPath (Join-Path $goc 'cau-noi\vcs-mcp-bridge.js') -Destination $vcs -Force
Dong ("Đã chép cầu nối vào {0}" -f $dich) 'Green'
if ($ChiChep) { exit 0 }

# ── 3. Gộp vào tệp cấu hình mcpServers (giữ máy chủ khác, sao lưu trước khi sửa) ──
$utf8 = New-Object Text.UTF8Encoding($false)
function GopCauHinh([string]$tep, [string]$ten) {
    $thuMuc = Split-Path -Parent $tep
    New-Item -ItemType Directory -Force -Path $thuMuc | Out-Null
    $cfg = $null
    if (Test-Path -LiteralPath $tep) {
        $raw = [IO.File]::ReadAllText($tep)
        if ($raw.Trim().Length -gt 0) {
            try { $cfg = $raw | ConvertFrom-Json }
            catch { Dong ("  Bỏ qua {0}: tệp không phải JSON hợp lệ, hãy sửa tay theo trang hướng dẫn." -f $tep) 'Yellow'; return }
        }
        Copy-Item -LiteralPath $tep -Destination ($tep + '.bak-' + (Get-Date -Format 'yyyyMMdd-HHmmss')) -Force
    }
    if ($null -eq $cfg) { $cfg = New-Object PSObject }
    if (-not $cfg.PSObject.Properties['mcpServers']) { $cfg | Add-Member -NotePropertyName mcpServers -NotePropertyValue (New-Object PSObject) }
    $may = $cfg.mcpServers
    $may | Add-Member -NotePropertyName 'hts-autocad' -NotePropertyValue ([pscustomobject]@{ command = $node.Source; args = @($hts) }) -Force
    $may | Add-Member -NotePropertyName 'vcs-boq' -NotePropertyValue ([pscustomobject]@{ command = $node.Source; args = @($vcs) }) -Force
    [IO.File]::WriteAllText($tep, (ConvertTo-Json -InputObject $cfg -Depth 20), $utf8)
    Dong ("  {0}: đã thêm hts-autocad + vcs-boq vào {1}" -f $ten, $tep) 'Green'
}

Dong ''
Dong 'Cấu hình ứng dụng AI:' 'Cyan'
$co = $false
# Claude Desktop: bản cài thường (%APPDATA%\Claude) + bản Microsoft Store (Packages\Claude_*\LocalCache\Roaming\Claude)
$claude = @()
if (Test-Path (Join-Path $env:APPDATA 'Claude')) { $claude += (Join-Path $env:APPDATA 'Claude\claude_desktop_config.json') }
Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Packages') -Directory -Filter 'Claude_*' -ErrorAction SilentlyContinue | ForEach-Object {
    $p = Join-Path $_.FullName 'LocalCache\Roaming\Claude'
    if (Test-Path $p) { $claude += (Join-Path $p 'claude_desktop_config.json') }
}
foreach ($t in $claude) { GopCauHinh $t 'Claude Desktop'; $co = $true }
if (Test-Path (Join-Path $env:USERPROFILE '.cursor')) { GopCauHinh (Join-Path $env:USERPROFILE '.cursor\mcp.json') 'Cursor'; $co = $true }
if (-not $co) { Dong '  Chưa thấy Claude Desktop / Cursor. Dùng đoạn cấu hình bên dưới cho ứng dụng của bạn.' 'Yellow' }

# ── 4. In cấu hình cho ứng dụng khác ─────────────────────────────
$j = { param($s) $s.Replace('\', '\\') }
Dong ''
Dong 'Claude Code (chạy trong PowerShell):' 'Cyan'
Dong ('  claude mcp add --scope user hts-autocad -- node "{0}"' -f $hts)
Dong ('  claude mcp add --scope user vcs-boq -- node "{0}"' -f $vcs)
Dong ''
Dong 'Ứng dụng khác (khoá "mcpServers"; VS Code dùng khoá "servers" và thêm "type": "stdio"):' 'Cyan'
Dong ('  "hts-autocad": {{ "command": "node", "args": ["{0}"] }},' -f (& $j $hts))
Dong ('  "vcs-boq":     {{ "command": "node", "args": ["{0}"] }}' -f (& $j $vcs))
Dong ''
Dong 'Xong. Thoát hẳn ứng dụng AI rồi mở lại; mở AutoCAD, gõ HTS (hoặc VCS) và đăng nhập.' 'Cyan'
