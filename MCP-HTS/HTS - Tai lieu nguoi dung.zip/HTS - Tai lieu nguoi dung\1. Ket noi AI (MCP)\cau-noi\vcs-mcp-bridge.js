#!/usr/bin/env node
/**
 * VCS MCP Bridge — bóc khối lượng (RIÊNG, tách khỏi VCSHOP 5088 và HTS-Design 5099)
 * ──────────────────────────────────────────────────────────────────────────────
 * Cầu nối: Claude Desktop / MCP client (stdio JSON-RPC) ↔ VCS HTTP server (localhost:5077).
 *
 *   • VCS.dll mở HttpListener tại http://localhost:5077/mcp/ SAU KHI kỹ sư gõ lệnh VCS và đăng nhập
 *     (GiaoDienV2/Mcp/VcsMcpServer.cs). Phiên hết hạn / bị thu hồi → server tắt, tool trả NOT_LICENSED.
 *   • Bridge chỉ chuyển tiếp tools/list, tools/call, ping. Chưa có server → trả tool "vcs_status" báo cách khắc phục.
 *
 * claude_desktop_config.json:
 *   "vcs-boq": { "command": "node", "args": ["C:\\ProgramData\\Autodesk\\ApplicationPlugins\\Htools.bundle\\Contents\\Windows\\VcsMcp\\vcs-mcp-bridge.js"] }
 *
 * Yêu cầu Node.js 18+ (fetch có sẵn). Log gỡ rối ra stderr (stdout dành cho JSON-RPC).
 */
"use strict";

const readline = require("readline");

const VCS_BASE = process.env.VCS_MCP_URL || "http://localhost:5077/mcp";
const PROTOCOL_VERSION = "2024-11-05";
const SERVER_INFO = { name: "vcs-boq-bridge", version: "1.0.0" };
const HEALTH_POLL_MS = 4000;

let _toolsCache = null;
let _initialized = false;
let _lastHealthOk = false;
let _pollTimer = null;

function logErr(m) { process.stderr.write("[vcs-mcp-bridge] " + m + "\n"); }

async function vcsHttp(pathPart, opts = {}) {
    const url = VCS_BASE + pathPart;
    const headers = { "Content-Type": "application/json", ...(opts.headers || {}) };
    let res;
    try { res = await fetch(url, { ...opts, headers }); }
    catch (e) { throw new Error(`Không kết nối được VCS tại ${url}. Mở AutoCAD, gõ lệnh VCS và đăng nhập. (${e.message})`); }
    const text = await res.text();
    if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}: ${text.slice(0, 300)}`);
    try { return JSON.parse(text); }
    catch (e) { throw new Error(`Response không phải JSON: ${text.slice(0, 300)}`); }
}

const STATUS_TOOL = {
    name: "vcs_status",
    description: "⚠️ VCS (bóc khối lượng) chưa kết nối tại " + VCS_BASE +
        ". Hãy: (1) Mở AutoCAD, (2) Gõ lệnh VCS và đăng nhập, (3) Gọi lại công cụ này để kiểm tra.",
    inputSchema: { type: "object", properties: {} },
};

const handlers = {
    "initialize": async () => ({
        protocolVersion: PROTOCOL_VERSION,
        capabilities: { tools: { listChanged: true } },
        serverInfo: SERVER_INFO,
    }),

    "notifications/initialized": async () => { _initialized = true; startHealthPoll(); return null; },

    "tools/list": async () => {
        try {
            const r = await vcsHttp("/tools/list");
            const raw = Array.isArray(r) ? r : (r.tools || []);
            const tools = raw.map((t) => {
                const tool = { name: t.name, description: t.description || "", inputSchema: t.inputSchema || t.parameters || { type: "object", properties: {} } };
                if (t.title) tool.title = t.title;
                if (t.annotations) tool.annotations = t.annotations;
                return tool;
            });
            if (tools.length > 0) { _toolsCache = tools; return { tools: [...tools, STATUS_TOOL] }; }
        } catch (e) {
            logErr("tools/list FAIL: " + e.message);
            if (_toolsCache && _toolsCache.length > 0) return { tools: [..._toolsCache, STATUS_TOOL] };
        }
        return { tools: [STATUS_TOOL] };
    },

    "tools/call": async (params) => {
        const name = params && params.name;
        const args = (params && params.arguments) || {};
        if (!name) throw new Error("Thiếu 'name' khi gọi tool");

        if (name === "vcs_status") {
            try {
                const h = await vcsHttp("/health");
                const ok = h.licensed ? "✅ VCS đang chạy, phiên hợp lệ" : "⚠️ VCS đang chạy nhưng CHƯA đăng nhập — gõ lệnh VCS trong AutoCAD";
                return { content: [{ type: "text", text: ok + ":\n" + JSON.stringify(h, null, 2) }], isError: !h.licensed };
            } catch (e) {
                return { content: [{ type: "text", text: "❌ VCS không kết nối được tại " + VCS_BASE + "\nLỗi: " + e.message +
                    "\n\nCách sửa: 1) Mở AutoCAD  2) Gõ lệnh VCS, đăng nhập  3) Kiểm tra: curl " + VCS_BASE + "/health" }], isError: true };
            }
        }

        const r = await vcsHttp("/tools/call", { method: "POST", body: JSON.stringify({ name, arguments: args }) });
        let text = typeof r.content === "string" ? r.content : JSON.stringify(r.content != null ? r.content : r);
        if (r.error_code) text += "\nerror_code: " + r.error_code;
        if (r.hint) text += "\nhint: " + r.hint;
        if (r.truncated) text += "\ntruncated: true";
        if (r.data != null) text += "\n\nData: " + (typeof r.data === "string" ? r.data : JSON.stringify(r.data));
        return { content: [{ type: "text", text }], isError: r.success === false };
    },

    "ping": async () => ({}),
};

function send(obj) { process.stdout.write(JSON.stringify(obj) + "\n"); }

function startHealthPoll() {
    if (_pollTimer) return;
    _pollTimer = setInterval(async () => {
        let ok = false;
        try { await vcsHttp("/health"); ok = true; } catch (_) { ok = false; }
        if (ok !== _lastHealthOk) {
            _lastHealthOk = ok;
            logErr(`Health -> ${ok ? "ONLINE" : "OFFLINE"}; báo tools/list_changed`);
            if (_initialized) send({ jsonrpc: "2.0", method: "notifications/tools/list_changed" });
        }
    }, HEALTH_POLL_MS);
    if (_pollTimer.unref) _pollTimer.unref();
}

const rl = readline.createInterface({ input: process.stdin, terminal: false });
rl.on("line", async (line) => {
    line = line.trim();
    if (!line) return;
    let msg;
    try { msg = JSON.parse(line); } catch (e) { logErr("Bỏ dòng không phải JSON: " + line.slice(0, 100)); return; }
    const isNotification = msg.id === undefined || msg.id === null;
    const reply = { jsonrpc: "2.0", id: msg.id };
    try {
        const handler = handlers[msg.method];
        if (!handler) reply.error = { code: -32601, message: "Method not found: " + msg.method };
        else {
            const result = await handler(msg.params || {});
            if (result === null && isNotification) return;
            reply.result = result === null ? {} : result;
        }
    } catch (e) {
        logErr(`Error handling ${msg.method}: ${e.message}`);
        reply.error = { code: -32603, message: e.message };
    }
    if (!isNotification) send(reply);
});
rl.on("close", () => { logErr("stdin closed → bridge exit."); process.exit(0); });

logErr(`VCS MCP Bridge started. VCS_BASE=${VCS_BASE}`);
(async () => {
    try { const h = await vcsHttp("/health"); _lastHealthOk = true; logErr(`✅ health OK: tools=${h.toolCount} licensed=${h.licensed}`); }
    catch (e) { _lastHealthOk = false; logErr(`❌ health FAIL: ${e.message} — mở AutoCAD + lệnh VCS, bridge tự nạp tool khi lên.`); }
})();
