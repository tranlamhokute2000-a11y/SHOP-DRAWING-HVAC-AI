#!/usr/bin/env node
/**
 * HTS-AutoCAD MCP Bridge
 * ──────────────────────
 * Cầu nối: Claude Desktop (MCP stdio JSON-RPC) ↔ HTS HTTP server (localhost:5088).
 *
 * AutoCAD phải đang mở + HTS load (port 5088 lắng nghe).
 *
 * Auth: HTS chấp nhận request từ loopback KHÔNG có Origin/Referer như "internal call"
 *       → Node fetch mặc định không gửi 2 header này → bridge gọi được mà không cần token.
 *       Để chắc chắn lâu dài, bridge cũng thử lấy Bearer token qua /auth/token rồi dùng.
 *
 * Yêu cầu: Node.js 18+ (có fetch built-in).
 */

"use strict";

const readline = require("readline");

const HTS_BASE = process.env.HTS_MCP_URL || "http://localhost:5088/mcp";
const PROTOCOL_VERSION = "2024-11-05";
const SERVER_INFO = { name: "hts-autocad-bridge", version: "1.0.0" };

let bearerToken = null;       // sẽ thử lấy lazily qua /auth/token nếu cần
let _toolsCache = null;        // cache tools list để recover nếu HTS tắt giữa session
let _initialized = false;      // client đã gửi notifications/initialized chưa
let _lastHealthOk = false;     // trạng thái reachable lần poll trước (để chỉ báo khi ĐỔI)
let _pollTimer = null;         // timer poll /health
const HEALTH_POLL_MS = 4000;   // chu kỳ poll AutoCAD lên/xuống

// ─── Helpers ────────────────────────────────────────────────────────
function logErr(msg) {
    // Mọi log debug PHẢI ghi ra stderr (stdout dành riêng cho JSON-RPC reply).
    process.stderr.write("[hts-mcp-bridge] " + msg + "\n");
}

async function htsHttp(pathPart, opts = {}) {
    const url = HTS_BASE + pathPart;
    const headers = { "Content-Type": "application/json", ...(opts.headers || {}) };
    if (bearerToken) headers["Authorization"] = "Bearer " + bearerToken;

    let res;
    try {
        res = await fetch(url, { ...opts, headers });
    } catch (e) {
        throw new Error(
            `Không kết nối được HTS server tại ${url}. ` +
            `Đảm bảo AutoCAD đang mở và HTS đã load. (${e.message})`
        );
    }

    const text = await res.text();
    if (!res.ok) {
        // 401 → có thể do auth fail; thử lấy token rồi retry 1 lần
        if (res.status === 401 && !bearerToken) {
            try {
                const tokRes = await fetch(HTS_BASE + "/auth/token");
                if (tokRes.ok) {
                    const tok = await tokRes.json();
                    if (tok && tok.token) {
                        bearerToken = tok.token;
                        logErr("Đã lấy được Bearer token, retry...");
                        return htsHttp(pathPart, opts);
                    }
                }
            } catch (_) { /* ignore */ }
        }
        // 403 NOT_LICENSED: HTS chưa đăng nhập bản quyền / phiên hết hạn / bị thu hồi — chỉ người có bản quyền mới dùng được MCP
        if (res.status === 403 && text.indexOf("NOT_LICENSED") >= 0) {
            const e = new Error("HTS chưa xác thực bản quyền (hoặc phiên đã hết hạn / bị thu hồi). Mở AutoCAD, gõ lệnh HTS và đăng nhập tài khoản có bản quyền.");
            e.notLicensed = true;
            throw e;
        }
        throw new Error(`HTS HTTP ${res.status} ${res.statusText}: ${text.slice(0, 300)}`);
    }

    try {
        return JSON.parse(text);
    } catch (e) {
        throw new Error(`HTS trả response không phải JSON: ${text.slice(0, 300)}`);
    }
}

// ─── MCP method handlers ────────────────────────────────────────────
const handlers = {
    /** Khởi tạo session — Claude Desktop gọi đầu tiên. */
    "initialize": async () => ({
        protocolVersion: PROTOCOL_VERSION,
        // listChanged:true → BÁO cho Claude Desktop rằng danh sách tool CÓ THỂ đổi.
        // Nhờ vậy khi AutoCAD mở SAU lúc Claude khởi động, bridge gửi
        // notifications/tools/list_changed → Claude tự gọi lại tools/list → nạp đủ tool,
        // KHÔNG cần restart Claude Desktop. Trước đây thiếu cờ này nên kẹt ở hts_status.
        capabilities: { tools: { listChanged: true } },
        serverInfo: SERVER_INFO,
    }),

    "notifications/initialized": async () => {
        _initialized = true;
        startHealthPoll();          // bắt đầu theo dõi AutoCAD lên/xuống
        return null;                // notification, không cần reply
    },

    /** Liệt kê tools. HTS trả {tools:[{name,description,parameters}]} → đổi sang inputSchema.
     *  Nếu HTS chưa reachable → trả 1 sentinel tool "hts_status" giải thích vấn đề
     *  để user thấy ngay trong Claude Desktop UI thay vì "no tools available". */
    "tools/list": async () => {
        try {
            const r = await htsHttp("/tools/list");
            const raw = Array.isArray(r) ? r : (r.tools || []);
            const tools = raw.map((t) => ({
                name: t.name,
                description: t.description || "",
                // MCP yêu cầu key "inputSchema" (không phải "parameters")
                inputSchema: t.parameters || t.inputSchema || { type: "object", properties: {} },
            }));
            if (tools.length > 0) {
                _toolsCache = tools;     // cache để fallback nếu HTS tắt giữa session
                logErr(`tools/list OK — ${tools.length} tools.`);
                return { tools };
            }
            // HTS up nhưng 0 tools (lạ) → vẫn trả sentinel
            logErr("tools/list trả 0 tools — HTS có thể chưa register.");
        } catch (e) {
            logErr("tools/list FAIL: " + e.message);
            // Không có bản quyền → KHÔNG trả danh sách cũ (mọi lời gọi đều bị từ chối), chỉ trả hts_status
            if (e.notLicensed) {
                _toolsCache = null;
                return { tools: [{ name: "hts_status", description: "⚠️ " + e.message, inputSchema: { type: "object", properties: {} } }] };
            }
            // Nếu có cache cũ → dùng (HTS có thể vừa restart)
            if (_toolsCache && _toolsCache.length > 0) {
                logErr(`Trả ${_toolsCache.length} tools từ cache cũ.`);
                return { tools: _toolsCache };
            }
        }

        // Fallback: trả sentinel tool để Claude Desktop hiển thị thông điệp rõ ràng
        return {
            tools: [
                {
                    name: "hts_status",
                    description:
                        "⚠️ HTS-AutoCAD chưa kết nối được tại " + HTS_BASE + ". " +
                        "Hãy: (1) Mở AutoCAD, (2) Đảm bảo HTS Add-in đã load, " +
                        "(3) RESTART Claude Desktop để fetch lại tools list.",
                    inputSchema: { type: "object", properties: {} },
                },
            ],
        };
    },

    /** Gọi 1 tool. HTS trả {success, content, data} → đổi sang MCP {content:[{type:"text", text}]}. */
    "tools/call": async (params) => {
        const name = params && params.name;
        const args = (params && params.arguments) || {};
        if (!name) throw new Error("Thiếu tham số 'name' khi gọi tool");

        // Sentinel tool — gọi để check trạng thái HTS từ Claude Desktop UI
        if (name === "hts_status") {
            try {
                const h = await htsHttp("/health");
                if (h && h.licensed === false) {
                    return {
                        content: [{ type: "text", text: "⛔ HTS đang chạy nhưng CHƯA có bản quyền hiệu lực (chưa đăng nhập, phiên hết hạn hoặc bị thu hồi). Mở AutoCAD, gõ lệnh HTS và đăng nhập tài khoản có bản quyền — chỉ người có bản quyền mới dùng được MCP." }],
                        isError: true,
                    };
                }
                return {
                    content: [{
                        type: "text",
                        text: "✅ HTS đang chạy: " + JSON.stringify(h, null, 2)
                            + "\n\nNếu vẫn thấy chỉ có hts_status, RESTART Claude Desktop để fetch tools list."
                    }],
                    isError: false,
                };
            } catch (e) {
                return {
                    content: [{
                        type: "text",
                        text: "❌ HTS không reachable tại " + HTS_BASE + "\n" +
                              "Lỗi: " + e.message + "\n\n" +
                              "Bước fix:\n" +
                              "1. Mở AutoCAD\n" +
                              "2. Load HTS Add-in (NETLOAD VCSHOP.dll)\n" +
                              "3. Test: curl http://localhost:5088/mcp/health\n" +
                              "4. Restart Claude Desktop"
                    }],
                    isError: true,
                };
            }
        }

        const r = await htsHttp("/tools/call", {
            method: "POST",
            body: JSON.stringify({ name, arguments: args }),
        });

        // Format kết quả thành MCP content array
        let text = "";
        if (typeof r.content === "string") text = r.content;
        else if (r.content !== undefined && r.content !== null) text = JSON.stringify(r.content);
        else text = JSON.stringify(r);

        if (r.data !== undefined && r.data !== null) {
            text += "\n\nData: " + (typeof r.data === "string" ? r.data : JSON.stringify(r.data));
        }

        return {
            content: [{ type: "text", text }],
            isError: r.success === false,
        };
    },

    /** Hỗ trợ ping (Claude Desktop đôi khi gửi để kiểm tra alive). */
    "ping": async () => ({}),
};

// ─── stdio JSON-RPC loop ────────────────────────────────────────────
function send(obj) {
    process.stdout.write(JSON.stringify(obj) + "\n");
}

/**
 * Poll /health định kỳ. Khi trạng thái reachable ĐỔI (AutoCAD vừa mở hoặc vừa tắt),
 * gửi notifications/tools/list_changed để Claude Desktop tự fetch lại tools/list.
 * Nhờ vậy: mở AutoCAD sau khi Claude đã chạy → tool tự xuất hiện, khỏi restart.
 */
function startHealthPoll() {
    if (_pollTimer) return;
    _pollTimer = setInterval(async () => {
        let ok = false;
        // ONLINE = máy chủ trả lời VÀ bản quyền đang hiệu lực (đăng nhập / hết hạn đổi trạng thái → client nạp lại danh sách tool)
        try { const h = await htsHttp("/health"); ok = !(h && h.licensed === false); } catch (_) { ok = false; }
        if (ok !== _lastHealthOk) {
            _lastHealthOk = ok;
            logErr(`Health đổi -> ${ok ? "ONLINE (AutoCAD lên)" : "OFFLINE"}; báo tools/list_changed`);
            if (_initialized) send({ jsonrpc: "2.0", method: "notifications/tools/list_changed" });
        }
    }, HEALTH_POLL_MS);
    if (_pollTimer.unref) _pollTimer.unref();   // không giữ tiến trình sống chỉ vì timer
}

const rl = readline.createInterface({ input: process.stdin, terminal: false });

rl.on("line", async (line) => {
    line = line.trim();
    if (!line) return;

    let msg;
    try {
        msg = JSON.parse(line);
    } catch (e) {
        logErr("Bỏ qua dòng không phải JSON: " + line.slice(0, 100));
        return;
    }

    // Notification: không có id → không trả lời
    const isNotification = msg.id === undefined || msg.id === null;

    const reply = { jsonrpc: "2.0", id: msg.id };
    try {
        const handler = handlers[msg.method];
        if (!handler) {
            reply.error = { code: -32601, message: "Method not found: " + msg.method };
        } else {
            const result = await handler(msg.params || {});
            if (result === null && isNotification) return; // notification: không reply
            reply.result = result === null ? {} : result;
        }
    } catch (e) {
        logErr(`Error handling ${msg.method}: ${e.message}`);
        reply.error = { code: -32603, message: e.message };
    }

    if (!isNotification) send(reply);
});

rl.on("close", () => {
    logErr("stdin closed → bridge exit.");
    process.exit(0);
});

logErr(`HTS-AutoCAD MCP Bridge started. HTS_BASE=${HTS_BASE}`);

// Probe HTS health ngay khi khởi động — log rõ ràng để user debug.
(async () => {
    try {
        const h = await htsHttp("/health");
        _lastHealthOk = true;   // đặt baseline: đã online lúc start → không gửi list_changed thừa
        logErr(`✅ HTS health OK: server=${h.server} version=${h.version} toolCount=${h.toolCount}`);
    } catch (e) {
        _lastHealthOk = false;
        logErr(`❌ HTS health FAIL: ${e.message}`);
        logErr(`   → Mở AutoCAD; bridge tự phát hiện và nạp tool (không cần restart Claude).`);
    }
})();
