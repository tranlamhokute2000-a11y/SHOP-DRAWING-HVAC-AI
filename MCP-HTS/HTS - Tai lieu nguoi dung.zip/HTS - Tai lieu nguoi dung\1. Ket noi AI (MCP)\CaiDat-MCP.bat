@echo off
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0cai-dat-mcp.ps1" %*
echo.
pause
